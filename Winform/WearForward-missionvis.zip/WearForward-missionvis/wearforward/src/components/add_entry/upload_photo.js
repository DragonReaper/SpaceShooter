import React, {useState} from "react"

function UploadPhoto(){
	return(
		<div>
			<p>Body</p>
		</div>
		)
}

export default UploadPhoto
