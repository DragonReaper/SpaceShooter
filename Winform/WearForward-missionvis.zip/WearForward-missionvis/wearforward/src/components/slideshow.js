import React, { useState } from "react";

function Slideshow() {
  return (
    <div>
      <p>Hello I am the slideshow</p>
    </div>
  );
}

export default Slideshow;
